package com.skillenza.parkinglotjava;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ParkinglotjavaApplicationTests {


	
 //your test goes here

    @MockBean
    ParkingLotRepository parkingLotRepository;

    @Autowired
    ParkingLotService parkingLotService;


    @Test
    public void parkNewVehicle(){
        Mockito.when ( parkingLotRepository.save ( Mockito.any (ParkingLot.class) ) ).thenReturn ( new ParkingLot () );
        ParkingLot poLot=new ParkingLot ();
        poLot.setLot ( 3 );
        Mockito.verify ( parkingLotService.occupyParkingLot ( poLot ) );
    }


    @Test(expected=ParkingLotException.class)
    public void vehicleAlreadyParked(){
        ParkingLot parkingLot=new ParkingLot ();
        parkingLot.setLot ( 3 );
        parkingLot.setParkingDuration ( 1000 );
        parkingLot.setCreatedAt (LocalDateTime.now () );
        List<ParkingLot> parkingLots=new ArrayList<> (  );
        parkingLots.add ( parkingLot );
        Mockito.when ( parkingLotRepository.findAll ( Sort.by ( Sort.Order.desc ( "id" ) ) ) ).thenReturn (parkingLots );
        Mockito.verify ( parkingLotService.occupyParkingLot ( parkingLot ) );


    }


}
