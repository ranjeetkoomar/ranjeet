package com.skillenza.parkinglotjava;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Ranjeet
 */

@Service
public class ParkingLotService {

    @Autowired
    ParkingLotRepository parkingLotRepository;

    public List<ParkingLot> parkingLots(){
        return parkingLotRepository.findAll ( Sort.by ( Sort.Order.desc ( "id" ) ) );
    }

    public ParkingLot occupyParkingLot(ParkingLot parkingLot) throws ParkingLotException{

        List<ParkingLot> parkingLotList=parkingLots();
        parkingLotList=parkingLotList.parallelStream ().filter ( p-> p.getLot ()==parkingLot.getLot () ).collect(Collectors.toList());

        if (parkingLotList.size ()==0 ){
           return parkLot(parkingLot);
        }else{
            LocalDateTime dateTime=parkingLotList.get ( 0 ).getCreatedAt ().plusMinutes ( parkingLotList.get ( 0 ).getParkingDuration () );
            if (Duration.between (LocalDateTime.now (), dateTime  ).isNegative ()){
                throw new ParkingLotException ("VEHICLE ALREADY PARKED");
            }else{
                unparkLot(parkingLotList.get ( 0 ));
            }
        }
        return parkLot(parkingLot);
    }

    public ParkingLot parkLot(ParkingLot parkingLot){

        int parkingDuration=parkingLot.getParkingDuration ();
        if (parkingDuration>60){
            parkingLot.setParkingAmount ((int)( 20+(parkingDuration-60)*0.333F ));
        }
        return parkingLotRepository.save ( parkingLot );
    }

    public void unparkLot(ParkingLot parkingLot){

        parkingLotRepository.delete ( parkingLot );
    }
}
