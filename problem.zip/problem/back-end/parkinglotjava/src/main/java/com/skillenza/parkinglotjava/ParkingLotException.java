package com.skillenza.parkinglotjava;

import java.security.PrivateKey;

/**
 * @author Ranjeet
 */
public class ParkingLotException extends RuntimeException {
    @Override
    public String getMessage() {
        return message;
    }

    private String message;

    ParkingLotException(String message){
        this.message=message;
    }
}
