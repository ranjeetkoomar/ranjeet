package com.skillenza.parkinglotjava;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api")
public class ParkingLotController {

    @Autowired
    ParkingLotService parkingLotService;
    // your code goes here

    @GetMapping("/parkings")
    public List<ParkingLot> occupiedParkingsLot(){
        return parkingLotService.parkingLots ();
    }

    @PostMapping("/parkings")
    public ParkingLot occupyParkingLot(ParkingLot parkingLot){
        return parkingLotService.occupyParkingLot ( parkingLot );
    }
}

