cd back-end
mvn spring-boot:run
http://localhost:8080/api/


cd front-end
ng serve
http://localhost:4200/

